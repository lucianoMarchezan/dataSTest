/** Automatically generated file. DO NOT MODIFY */
package net.apogames.apomono;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}