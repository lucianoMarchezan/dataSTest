CREATE TABLE `broken_cre_results` (
  `idsbrokencres` int NOT NULL AUTO_INCREMENT,
  `model_name` varchar(100) DEFAULT NULL,
  `cre` varchar(100) DEFAULT NULL,
  `crd` varchar(100) DEFAULT NULL,
  `repair` text DEFAULT NULL,
  `broken_cre_count` int DEFAULT NULL,
  `broken_cres` text,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idsbrokencres`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
SELECT * FROM dependency_evaluation.broken_cre_results;