package org.apogames;

import java.awt.Canvas;
import java.awt.Graphics;

public class ApoCanvas extends Canvas {

	private static final long serialVersionUID = 1L;

	public void paint(Graphics g) {
	}

	public void update(Graphics g) {
	}
}
