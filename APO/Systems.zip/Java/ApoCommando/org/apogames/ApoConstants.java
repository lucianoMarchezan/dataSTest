package org.apogames;

/**
 * Konstanten
 * @author Dirk Aporius
 *
 */
public class ApoConstants {

	/** gibt zur�ck, ob die Anwendung eine Applikation oder ein Applet ist */
	public static boolean B_APPLET = false;
	/** gibt zur�ck, ob die Anwendung eine Applikation oder ein Applet ist */
	public static boolean B_FPS = false;
	/** gibt zur�ck, ob die Anwendung online ist */
	public static boolean B_ONLINE = false;

}
