CREATE TABLE `repair_tree_results` (
  `idrepairs` int NOT NULL AUTO_INCREMENT,
  `model_name` varchar(45) DEFAULT NULL,
  `cre` varchar(500) DEFAULT NULL,
  `cr` varchar(50) DEFAULT NULL,
  `repairs` int DEFAULT NULL,
  PRIMARY KEY (`idrepairs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
