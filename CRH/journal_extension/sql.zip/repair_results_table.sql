CREATE TABLE `repair_results` (
  `idrepair` int NOT NULL AUTO_INCREMENT,
  `model_name` varchar(45) DEFAULT NULL,
  `cre` varchar(100) DEFAULT NULL,
  `cr` varchar(50) DEFAULT NULL,
  `repair` varchar(1500) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `time` double DEFAULT NULL,
  `memory` bigint DEFAULT NULL,
  `pse` int DEFAULT NULL,
  `nse` int DEFAULT NULL,
  PRIMARY KEY (`idrepair`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
