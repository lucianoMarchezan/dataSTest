the results from the similary analysis were calculated using two metrics: bleu2 [1] and Cosine similarity [2]. 
Scripts are available in this folder in the file ruleSimilarity.ipynb

1. Papineni, Kishore, et al. "Bleu: a method for automatic evaluation of machine translation." Proceedings of the 40th annual meeting of the Association for Computational Linguistics. 2002.

2. Rahutomo, Faisal, Teruaki Kitasuka, and Masayoshi Aritsugi. "Semantic cosine similarity." The 7th international student conference on advanced science and technology ICAST. Vol. 4. No. 1. 2012.