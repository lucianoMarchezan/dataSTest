/** Automatically generated file. DO NOT MODIFY */
package com.apogames.mytreasure;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}