/** Automatically generated file. DO NOT MODIFY */
package net.apogames.apodice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}