package net.gliblybits.bitsengine.gui.widgets.listener;

public interface 
BitsProgressBarListener {

	public boolean onProgressBarValueChanged( final int id, final float value );
}
